from django.apps import AppConfig


class VulAppConfig(AppConfig):
    name = 'vul_app'
